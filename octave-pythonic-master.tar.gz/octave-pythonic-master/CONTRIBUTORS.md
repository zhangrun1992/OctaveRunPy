# Contributors

- NVS Abhilash
- Juan Pablo Carbajal
- Avinoam Kalma
- Vijay Krishnavanshi
- Colin Macdonald
- Mike Miller
- Kai Torben Ohlhus
- Abhinav Tripathi

---

Thanks to the authors of the original Pytave project, which served as the
origin and inspiration of this project:

- David Grundberg
- Håkan Fors Nilsson
- Jaroslav Hájek

And thanks to Jordi Gutiérrez Hermoso, who originally proposed the idea of
adapting the Pytave project into a built-in interface between Octave and
Python.
